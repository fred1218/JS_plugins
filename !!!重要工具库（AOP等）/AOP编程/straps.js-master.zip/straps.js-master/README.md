## straps.js

Class inheritance library with support for bean-style accessors.

Copyright © 2006 - 2013, Jürg Lehni.

straps.js was created by extracting and simplifying the inheritance framework
from boostrap.js, a JavaScript DOM library, also created by Juerg Lehni:
https://github.com/lehni/bootstrap.js

The name was changed due to Twitter's introduction of their CSS framework with
the same name.

Documentation coming soon.
