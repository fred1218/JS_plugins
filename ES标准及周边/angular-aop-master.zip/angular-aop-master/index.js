"require angular"
"require ./src/angular-aop.js"
