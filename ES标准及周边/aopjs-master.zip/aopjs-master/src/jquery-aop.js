(function ($, global, undefined) {

    "use strict";

    $.aop = global.AOP;
    
    $.aop.noConflict();

}(jQuery, this));