exports['meld:node'] = {
	environment: 'node',
	tests: ['**/*.js']
};
