Resources
=========

* [Older Branch (uses coffeescript and sockets)](https://github.com/ProLoser/AngularJS-ORM/tree/coffee-sockets)
* [ES6 Cheat Sheet](ES6-Cheat-Sheet.md)
* [Slidedeck](http://slid.es/proloser/angularjs-orm) (OLD)  
* [Conference talk video](http://www.youtube.com/watch?v=Iw-3qgG_ipU) (OLD)  
[![NG-Conf 2014 Talk](http://i1.ytimg.com/vi/Iw-3qgG_ipU/0.jpg)](http://www.youtube.com/watch?v=Iw-3qgG_ipU)
