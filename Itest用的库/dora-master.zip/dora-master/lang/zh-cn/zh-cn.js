DR.LANG['zh-cn'] = {
    'labelMap':{
        'bold': '加粗'
    }
};