//这里只放不是由模块产生的默认参数
(function () {

    var skin = 'cool';

    DR.defaultOptions = {
        zIndex: 10,
        lang: 'zh-cn',
        labelMap: {}
    };

})();