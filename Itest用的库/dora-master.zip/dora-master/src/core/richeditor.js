var RichEditor = DR.createClass("RichEditor", {
    constructor: function (editor) {
        this.editor = editor;
    }
});

DR.extendClass(RichEditor, BaseEditor);
