Jello Spring Demo
==============================

这个示例演示了 [jello](https://github.com/fex-team/jello) 如何与后端 spring mvc 结合。

新项目可以 clone 此项目，基于此项目扩展自己的业务代码。

## 注意事项

- velocity >= 1.7
