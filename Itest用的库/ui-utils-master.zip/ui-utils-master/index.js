angular.module('ui.utils', [
  'ui.scroll',
  'ui.scrollpoint',
  'ui.event',
  'ui.mask',
  'ui.validate',
  'ui.indeterminate',
  'ui.uploader'
]);
