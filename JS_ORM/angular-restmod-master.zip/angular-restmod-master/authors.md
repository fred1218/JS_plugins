Authors
=======

* Original code and mantained by: [Ignacio Baixas](https://github.com/iobaixas) - Platan.us
* Community and product vision: [Juan Ignacio Donoso](https://github.com/blackjid) - Platan.us

With help from:

* [Matt Miller](https://github.com/facultymatt) - The computed properties implementation.
* [Chris Hanson](https://github.com/chris-hanson) - The NestedDirtyModel plugin.
