
/**
 * (c) 2014 Tim Griesser
 * Bookshelf may be freely distributed under the MIT license.
 * For all details and documentation:
 * http://bookshelfjs.org
 *
 * version 0.8.2
 *
 */
module.exports = require('./lib/bookshelf')
