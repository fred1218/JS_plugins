tests-base
==========

Tests the Base Objects in the Bookshelf DataMapper
