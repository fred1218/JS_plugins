
module.exports = {

  Collection: require('./tests/collection'),

  Model: require('./tests/model'),

  Events: require('./tests/events'),

  Relation: require('./tests/relation'),

  Eager: require('./tests/eager')

};