Bookshelf handles one-to-one, one-to-many, and many-to-many associations by defining relationships on models.
