mysql --ssl-key=certs/client-key.pem --ssl-cert=certs/client-cert.pem -h 127.0.0.1 -P 3307
