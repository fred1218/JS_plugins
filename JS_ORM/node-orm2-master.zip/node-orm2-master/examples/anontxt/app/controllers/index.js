
module.exports = {
  home     : require('./home_controller'),
  messages : require('./messages_controller'),
  comments : require('./comments_controller')
};
