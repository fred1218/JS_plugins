module.exports = {
    db:  'nodebench_test_db',
    table: 'nodebench_test_table'
}