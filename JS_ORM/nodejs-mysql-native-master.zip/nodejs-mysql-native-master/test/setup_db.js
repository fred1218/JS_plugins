var mysql = require('../lib/mysql-native')
var createConnection = require('./common').createConnection;

/*
var db = createConnection();
db.query('create database if not exists test', function() {
    db.close();
});
*/