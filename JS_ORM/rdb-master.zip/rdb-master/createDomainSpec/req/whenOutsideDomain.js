var when = require('a').when;
var c = {};

when(c)
.it('should return a new domain').assertEqual(c.newDomain, c.returned)