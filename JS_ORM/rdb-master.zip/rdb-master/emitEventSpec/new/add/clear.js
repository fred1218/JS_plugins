function act(c) {
	c.sut.clear();
}

act.base = '../add';
module.exports = act;