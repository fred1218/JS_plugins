function act(c) {
	c.sut();
}

act.base = '../new';
module.exports = act;