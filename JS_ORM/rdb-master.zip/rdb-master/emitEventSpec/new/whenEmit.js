var when = require('a').when;
var c = {};

when(c)
	.it('should not crash').assertOk('ok');