var when = require('a').when;
var c = {};

when(c)
	.it('should return negotiatedFilter').assertEqual(c.expected, c.returned)
	