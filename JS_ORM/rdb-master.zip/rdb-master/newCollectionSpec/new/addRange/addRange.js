var range2 = {};

function act(c) {
	c.element5 = {};
	c.sut.add(c.element5);
}

module.exports = act;