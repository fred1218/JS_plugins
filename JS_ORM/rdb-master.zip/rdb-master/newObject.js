function newObject() {
	return {};
}

module.exports = newObject;