
//todo
// require('pg').types.setTypeParser(1082, function(val) { return val; });