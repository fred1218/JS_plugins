var when = require('a').when;
var c = {};

when(c)
	.it('should end all pools').assertEqual(c.expected, c.returned)
