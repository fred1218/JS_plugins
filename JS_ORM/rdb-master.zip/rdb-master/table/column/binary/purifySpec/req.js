function act(c) {
	c.sut = require('../purify');
}

module.exports = act;