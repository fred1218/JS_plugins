var when = require('a').when;
var c = {};

when(c).
	it('shold purify value').assertEqual(c.expected, c.returned);