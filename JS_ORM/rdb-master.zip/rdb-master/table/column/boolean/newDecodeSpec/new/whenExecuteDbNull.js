var when = require('a').when;
var c = {};

when(c).
	it('shold return null').assertStrictEqual(null,c.returned);