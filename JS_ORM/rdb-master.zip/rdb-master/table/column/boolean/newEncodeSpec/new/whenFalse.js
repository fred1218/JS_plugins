var when = require('a').when;
var c = {};

when(c).
	it('shold return expected').assertEqual(c.expected,c.returned);