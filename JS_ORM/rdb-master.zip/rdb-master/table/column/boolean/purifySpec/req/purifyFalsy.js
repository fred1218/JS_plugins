function act(c) {
	c.returned = c.sut(0);
}

module.exports = act;