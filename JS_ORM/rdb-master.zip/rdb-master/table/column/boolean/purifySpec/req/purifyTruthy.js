function act(c) {
	c.returned = c.sut(2);
}

module.exports = act;