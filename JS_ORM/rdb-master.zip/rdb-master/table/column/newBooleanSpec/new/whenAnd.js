var when = require('a').when;
var c = {};

when(c).
	it('should return anded expression').assertEqual(c.expected,c.returned);
