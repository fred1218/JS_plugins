var when = require('a').when;
var c = {};

when(c)
	.it('should return next appended').assertEqual(c.expected,c.returned)
	;
