var containsCore = require('./containsCore');

module.exports = containsCore.bind(null, 'LIKE');
