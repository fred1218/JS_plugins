var when = require('a').when;
var c = {};

when(c)
.it('should return param').assertEqual(c.expected, c.returned);