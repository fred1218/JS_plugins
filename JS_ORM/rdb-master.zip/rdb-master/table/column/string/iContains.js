var containsCore = require('./containsCore');

module.exports = containsCore.bind(null, 'ILIKE');
