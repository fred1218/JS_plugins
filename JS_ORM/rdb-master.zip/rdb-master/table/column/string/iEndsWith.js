var endsWithCore = require('./endsWithCore');

module.exports = endsWithCore.bind(null, 'ILIKE');
