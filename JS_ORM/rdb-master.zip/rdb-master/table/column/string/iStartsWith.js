var startsWithCore = require('./startsWithCore');

module.exports = startsWithCore.bind(null, 'ILIKE');