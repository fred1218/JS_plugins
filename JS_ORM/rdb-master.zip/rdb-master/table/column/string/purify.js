function purify(value) {
	if(value == null)
		return null;
	return value;
}

module.exports = purify;