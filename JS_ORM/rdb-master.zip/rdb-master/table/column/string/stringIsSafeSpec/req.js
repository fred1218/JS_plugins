function act(c){
	c.sut = require('../stringIsSafe');
}

module.exports = act;