function act(c){
	c.returned = c.sut('abc');
}

module.exports = act;