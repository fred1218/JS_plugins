# Imprint - Boring legal stuff for the rest of us.
As there are people who are suing for fun and glory, you can find the respective information about the author of the page right here. Have fun reading ...

## AUTHOR(S)

```
Main author:
 
Sascha Depold
Uhlandstr. 122
10717 Berlin
sascha [at] depold [dot] com
[plus] 49 152 [slash] 03878582
```

## INHALTLICHE VERANTWORTUNG

```
Ich übernehme keine Haftung für ausgehende Links. 
Daher musst du dich bei Problemen an deren Betreiber wenden!
```
