/**
  The entry point.
  @module Sequelize
**/
module.exports = require("./lib/sequelize");
