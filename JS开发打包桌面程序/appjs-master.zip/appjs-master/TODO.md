# For 0.1.0

* Fix alpha compositing on OSX
* npm publish appjs-win
* npm publish appjs-mac
* npm publish appjs-linux
* npm publish appjs
* appjs/bin/* for appjs cli
* `$ appjs package [someapp]`
* Hot keys for Mac like CMD + Q, CMD + V
* Templatize functions like Emit to handle arbitrary args
* Figure out permissions to allow PointerLock and others
* Basic documentation

# For 0.3.0

* Switch to Chromium Content API
* Get Audio working
* Menu API
* Tray API
* Full blown Packager/Installer
* GUI for help
* GUI for NPM
* GUI for packager
