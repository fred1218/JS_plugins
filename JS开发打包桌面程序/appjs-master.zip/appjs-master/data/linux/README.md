# AppJS - Linux
This is the Linux package for AppJS. See the included appjs folder for the full README.

---

* __Site: [appjs.org](http://appjs.org)__
* __Community: [mailing list](https://groups.google.com/forum/#!forum/appjs-dev)__

---



## License
( The MIT License )

Copyright (c) 2012 Morteza Milani and other AppJS contributors

See the LICENSE file for details.
