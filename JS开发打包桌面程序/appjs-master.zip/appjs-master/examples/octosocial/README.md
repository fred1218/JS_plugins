# Octosocial

This is a simple example to show what can be done with AppJS.

It connects to your github account and shows a list of followers
/following users.

## How to

You need to install `github` module to run the example:

    $ npm install github

If you are a Windows user, please copy all required dlls to here.
See AppJS README for more information.
