#!/bin/sh

node --harmony index.js & wait
