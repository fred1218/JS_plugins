Chromeless is possible because of the [XULRunner] and [addon-sdk]
projects, both of which have a long list of contributors.  We'd like
to thank both of those projects and their contributors for being
awesome, as well as the following list of folks who have
directly helped build chromeless:

  [XULRunner]: https://developer.mozilla.org/en/xulrunner
  [addon-sdk]: https://github.com/mozilla/addon-sdk

<span class="aside">
  Because measuring the relative value of contributions is intractable,
  let's just be lexicographic about this.
</span>

* Alexandre Poirot
* Atul Varma
* Ben Francis
* David Coallier
* David Murdoch
* Ian Bicking
* Jim Pick
* Jonathan Ballet
* Jonathan Watt
* Lloyd Hilaiel
* Marcio Galli
* Mike de Boer
* Panagiotis Astithas
* Ron Evans
