const char * gettaStringFromNativeCode(void) 
{
    return "This string has come a loooong way";
}
