Notes 

This uses 3rd-party sylvester lib = MIT license
from here http://sylvester.jcoglan.com/ .

This demo will eventually render a browser thumbnail in the texture
we need to combine with the canvas-proxy module to get this working. 
This is so far a basic 3D cuble based on MDC article with a few modifications
to make it work with Gecko, see index.html notes 

You are welcome to help out with this sample and make a nice 3D view to tabs
and browsers. Here are other canvas/WebGL resources: 

https://developer.mozilla.org/en/WebGL



