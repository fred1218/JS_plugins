from _dirs import Dirs
from _appinfo import AppInfo
from _version import version
