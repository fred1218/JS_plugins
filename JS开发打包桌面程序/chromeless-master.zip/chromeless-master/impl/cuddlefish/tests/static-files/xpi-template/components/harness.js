// This file contains XPCOM code that bootstraps a
// Jetpack-based extension by loading its harness-options.json,
// registering all its resource directories, executing its loader,
// and then executing its main module's main() function.
