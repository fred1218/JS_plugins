/**
 * A test of basic class parsing
 */

/**
 * @class URL
 * A class which parses a url and exposes its various
 * components separately.
 */

/** @endclass */
