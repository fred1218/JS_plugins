/**
 * A test of basic class parsing
 */

/**
 * @class URL
 * A class which parses a url and exposes its various
 * components separately.
 */

/**
 * @constructor
 * This is the constructor of the class
 * @param {foo} bar it accepts a bar argument of type foo
 */

/** @endclass */
