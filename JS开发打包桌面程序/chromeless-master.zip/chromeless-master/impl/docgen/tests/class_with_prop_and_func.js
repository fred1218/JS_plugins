/**
 * A simple class with a property and a function
 */

/**
 * @class URL
 * A class which parses a url and exposes its various
 * components separately.
 */

/**
 * @property foo
 * the foo property of my url classs
 * @type string
 */

/**
 * @function bar
 * the foo property of my url classs
 * @returns nothing
 */

/** @endclass */
