/**
 * A module with a basic function definition in it
 */

/**
 * @function toFilename
 * a function which converts URLs to filenames
 */
