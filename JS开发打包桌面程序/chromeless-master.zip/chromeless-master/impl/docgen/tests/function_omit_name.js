/**
 * A module with a basic function definition in it,
 * but without explicit mention of the name of the function
 * given the heuristic name guessing stuff.
 */

/**
 * @function
 * a function which converts URLs to filenames
 */

let toFilename = exports.toFilename = function toFilename(url) {
}