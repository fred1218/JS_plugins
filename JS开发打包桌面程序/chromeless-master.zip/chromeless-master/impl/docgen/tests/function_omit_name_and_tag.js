/**
 * A module with a basic function definition in it,
 * which omits all tags, letting the system figure out
 * what we mean.
 */

/**
 * a function which converts URLs to filenames
 */
let toFilename = exports.toFilename = function toFilename(url) {
}
