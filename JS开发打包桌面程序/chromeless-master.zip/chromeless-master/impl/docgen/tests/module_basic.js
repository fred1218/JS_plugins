/**
 *
 * This is a basic module, it doens't explicitly specify it's own name
 * and it uses the short form for doc-wide comments.
 *
 *   // this is code, it uses some markdown!
 *
 */
