/**
 * @class URL
 * A class which parses a url and exposes its various
 * components separately.
 */

/**
 * @module names_changed
 * This is a module who's wierd, it has its declaration
 * inside of a class declaration.  We could make this an error,
 * but why?
 */

/** @endclass */
