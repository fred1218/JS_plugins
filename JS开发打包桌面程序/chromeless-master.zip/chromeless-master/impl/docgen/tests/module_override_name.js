/**
 * @module some_other_name
 *
 * This module overrides the logic that assumes that the filename
 * *is* the module name.
 */
