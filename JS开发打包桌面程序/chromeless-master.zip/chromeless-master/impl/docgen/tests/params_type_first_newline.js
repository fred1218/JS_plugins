/**
 * A function which contains parameters expressed
 * with type before param name.
 */

/**
 * a function which converts URLs to filenames.
 * @param {string} url
 * The url to convert
 */
let toFilename = exports.toFilename = function toFilename(url) {
}
