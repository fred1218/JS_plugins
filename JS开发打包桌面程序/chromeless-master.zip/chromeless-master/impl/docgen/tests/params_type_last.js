/**
 * A function which contains parameters expressed
 * with name before type.
 */

/**
 * a function which converts URLs to filenames.
 * @param url {string} The url to convert
 */
let toFilename = exports.toFilename = function toFilename(url) {
}
