/**
 * A module to test implicit property documentation,
 * where the developer provides only a description
 */

/**
 * a property which exposes a name to you
 */
exports.name = "Lloyd Hilaiel";
