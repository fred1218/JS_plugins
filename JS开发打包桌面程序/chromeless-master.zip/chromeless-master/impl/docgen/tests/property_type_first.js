/** A module with a single property, and type before name */

/**
 * @property {integer} port
 * The port number of the URL, `null` if none was specified.
 */
