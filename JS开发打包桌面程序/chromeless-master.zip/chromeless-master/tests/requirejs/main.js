requirejs(["add"], function(addr) {
    console.log("1 + 2 is " + addr.add(1,2));
});
