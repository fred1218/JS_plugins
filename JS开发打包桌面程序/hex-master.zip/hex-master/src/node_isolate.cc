// Copyright (c) 2012 Youdao. All rights reserved. Use of this source code is
// governed by a BSD-style license that can be found in the LICENSE file.

#include "../../v8/include/v8.h"

namespace node {

v8::Isolate* node_isolate = v8::Isolate::GetCurrent();

}  // namespace node
