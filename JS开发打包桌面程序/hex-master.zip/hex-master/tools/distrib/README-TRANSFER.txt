Files in this directory have been copied from other locations in the Chromium
source tree. They have been modified only to the extent necessary to work in
the CEF Binary Distribution directory structure. Below is a listing of the
original file locations.

