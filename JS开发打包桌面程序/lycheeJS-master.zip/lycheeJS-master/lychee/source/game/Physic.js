
lychee.define('lychee.game.Physic').exports(function(lychee, global, attachments) {

	var Class = function(data) {
	};


	Class.prototype = {
	};


	return Class;

});

