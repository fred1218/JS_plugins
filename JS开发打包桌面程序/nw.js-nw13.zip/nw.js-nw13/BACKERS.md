# Bountysource Backers

Thank you to everyone who backed our [Bountysource campaign](https://salt.bountysource.com/teams/nwjs)!

### Your name and URL in BACKERS.md.

- Ashley Gullen (https://www.scirra.com/)
- Murray Hopkins
- Anatoly Pashin

