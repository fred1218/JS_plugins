#ifndef _CONTENT_NW_CONTENT_MAC_H
#define _CONTENT_NW_CONTENT_MAC_H

namespace nw {
class Menu;
}

void NWChangeAppMenu(nw::Menu* menu);

#endif
