steal('can',
	'funcunit',
	'documentjs',
	'jquery/build/lib.js')

steal('steal','steal/generate',
	'steal/build',
	'steal/build/pluginify',
	'steal/coffee',
	'steal/less',
	'steal/clean',
	'steal/parse',
	'steal/html/crawl')

steal('can/construct',
	'can/construct/proxy',
	'can/control',
	'can/control/route',
	'can/control/plugin',
	'can/model',
	'can/observe',
	'can/observe/attributes',
	'can/observe/backup',
	'can/observe/delegate',
	'can/observe/validations',
	'can/route',
	'can/view/ejs',
	'can/util/fixture',
	'can/view/modifiers',
	'can/view/mustache')

steal('can/util/func.js')

// .then('canui')
