//js jmvc/compress.js

load("steal/compress/compress.js")
var compress = new steal.Compress(['jmvc/jmvc.html','jmvc']);