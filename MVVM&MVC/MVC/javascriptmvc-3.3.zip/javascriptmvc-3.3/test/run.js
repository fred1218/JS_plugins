// loads each project's command line tests

STEALPRINT = false;

load("steal/test/run.js");

// funcunit here ...

load("funcunit/test/run.js");

load("jquery/test/run.js");


