@page tutorials.jquerypp Get Started with jQuery++
@parent tutorials 4

jQuery++ is a collection of useful jQuery libraries that provide the 
missing functionality necessary to implement and organize large-scale 
jQuery applications. It provides low-level utilities for things that 
jQuery doesn’t support.

You can find out everything you need to know about jQuery++ 
[at its site.](http://jquerypp.com) jQuery++ is included with 
JavaScriptMVC by default in the <code>jquery</code> folder in the root 
of your project.