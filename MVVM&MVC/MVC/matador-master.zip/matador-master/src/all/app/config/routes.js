module.exports = function (app) {
  return {
    '/': {'get': 'Home.index'}
  }
}
