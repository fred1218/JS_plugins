module.exports = function (app, config) {
  return function () {}
}
