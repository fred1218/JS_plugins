// Copyright The Obvious Corporation 2013

/**
 * @fileoverview
 * Dummy helper to trigger createHelper events.
 */

module.exports = function () {}
