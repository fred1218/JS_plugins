module.exports = function (app, config) {
  var Test = function () {}
  Test.test = true
  return Test
}
