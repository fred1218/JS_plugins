module.exports = function (app) {
  return {
    '/': 'Home.index',
  }
}
