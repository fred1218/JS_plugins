# We need to wait for SoyNode to finish compiling
sleep 3
