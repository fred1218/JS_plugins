module.exports = function (app) {
  return {
    '/soy': 'Template.soy',
    '/old': 'Template.old'
  }
}
