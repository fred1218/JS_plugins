/*globals Test */

Test.loginController = SC.Object.create({
  
  username: null,
  
  password: null,
  
  loggedIn: NO
  
});