/*globals Test */

Test.mainController = SC.Object.create({
  
  mode: null
  
});