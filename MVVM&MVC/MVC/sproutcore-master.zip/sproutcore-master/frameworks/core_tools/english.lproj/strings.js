// ==========================================================================
// Project:   CoreTools Strings
// Copyright: ©2011 Apple Inc.
// ==========================================================================
/*globals CoreTools */

// Place strings you want to localize here.  In your app, use the key and
// localize it using "key string".loc().  HINT: For your key names, use the
// english string with an underscore in front.  This way you can still see
// how your UI will look and you'll notice right away when something needs a
// localized string added to this file!
//
SC.stringsFor('English', {
  // "_String Key": "Localized String"
}) ;
