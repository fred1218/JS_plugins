

## Vaadin Components 0.3.0.beta9 (2015-09-18)

- Host apidoc and demo launch pages in vaadin-components instead of
maintaining independent project for those
(deprecated components-examples & components-apidoc)
- Examples and apidoc are bundled with vaadin-components so as it is
possible to run them either local or wen deployed in CDN.

## Vaadin Components 0.3.0.beta8 (2015-09-11)

- vaadin-components becomes a repository with references to vaadin components.
- `<vaadin-grid>` is split in a new project.

## Vaadin Components 0.3.0.beta7 (2015-09-02)

- Polymer updated to v1.1.1
- Renamed component `<v-grid>` to `<vaadin-grid>`
- Many improvements in [v-grid](https://github.com/vaadin/vaadin-grid/blob/master/CHANGES.md#vaadin-grid-v030beta7-2015-sept)

## Vaadin Grid v0.2.1 (2015-05-15)
- New *material design* theme.

## Vaadin Components 0.2.0 (2015-05-08)
- Polymer updated to v0.8.0-rc.7
- Added `<v-grid>` component.
