# v0.9.3/0.9.4 - 01/2015

This is a periodic maintenance release which includes minor fixes:

* Improvements to [callbacks](https://github.com/aurajs/aura/commit/bb3f377a46de119c0f2539a9044e7ffa4dea4d8e)
* [IE8 Fixes](https://github.com/aurajs/aura/commit/a1db9e0a7dbd820a2faced50addf1de11409efe6)
* [Typo improvements](https://github.com/aurajs/aura/commit/e066fe230e0b3840763d2590852644032e95a5ce)
* Simplified [examples](https://github.com/aurajs/aura/commit/748cabaa3c08d822c1defea5847edc0912fc463f)
* [Fixes for IE8 console](https://github.com/aurajs/aura/commit/f42e6b172f4b09f1f2d4fc5b18e00f547ee7c7e6)
* Added [module](https://github.com/aurajs/aura/commit/ba883dc463358b8c227fb0f20916dda35a437943) to globals

# v0.9.2 - 10/01/2013

* Component.prototype.invokeWithCallback handles the correct signature (#316 by @xcambar) 
* Harmonizes init of app.logger and sandbox.logger (#314 by @xcambar)

