## Requirements

[bower](http://bower.io/): run `npm install -g bower` if needed

[grunt-cli](http://gruntjs.com/getting-started): run `npm install -g grunt-cli` if needed

## Setup

Run `npm install` and `bower install`.

## Guides

There is [getting started guide](http://aurajs.github.io/getting-started/) that can help newcomers better understand Aura.

## API Docs

API Docs can be found [here](http://aurajs.github.io/api/).

Hack away!!!

