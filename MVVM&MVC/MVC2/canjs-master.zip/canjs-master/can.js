steal('can/util', 'can/control/route', 'can/model', 
	'can/view/mustache', 'can/component', function(can) {
	return can;
});