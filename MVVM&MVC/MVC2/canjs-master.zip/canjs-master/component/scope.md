@property {*} can.Component.prototype.scope
@parent can.Component.prototype

@deprecated {2.2} In 2.2 `scope` has been renamed to [can.Component::viewModel] to avoid confusion with [can.view.Scope]. `scope` is still available for backwards compatibility.

