@typedef {String} can.Control.eventDescription eventDescription
@parent can.Control.types

@signature `"[CONTEXT ][SELECTOR ]EVENTNAME"`

