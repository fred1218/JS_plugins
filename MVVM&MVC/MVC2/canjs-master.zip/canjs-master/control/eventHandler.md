@typedef {function} can.Control.eventHandler eventHandler(element, event)
@parent can.Control.types

@signature `function(element, event)`

