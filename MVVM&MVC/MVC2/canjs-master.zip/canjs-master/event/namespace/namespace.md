@hide

@page can.event.namespace 
@parent can.event.plugins
@plugin can/event/namespace
@test can/event/namespace/test.html
@download http://donejs.com/can/dist/can.event.namespace.js

**This plugin is in development and should not be included in the official documentation.**
