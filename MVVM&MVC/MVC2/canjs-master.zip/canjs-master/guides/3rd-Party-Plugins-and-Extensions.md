## AppSwitcher

Listens to changes in a can.route attribute and loads/unloads apps (can.Control). 

 - https://github.com/thecountofzero/tcoz/tree/master/app_switcher
 - thecountofzero, @countofzero