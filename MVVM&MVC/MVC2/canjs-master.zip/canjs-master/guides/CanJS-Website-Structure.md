## Home

Purpose: increase engagement with the project. Quickly help people understand CanJS and link to more information. 
 - Download button
 - Summarize features/benefits
 - Link/show social media, community activity
 - Show an example

## About ? 
Could just link to the homepage, be renamed "Home", or if there is other content? (Might be best to remove it)

## Guides

Purpose: direct people how to learn CanJS.

Links to:

 - API guide
 - CanJS Video
 - Developing CanJS
 - Recipes Page
 - Docs
 - Annotated Source

## API

Formal documentation for CanJS's API

## Community

Purpose: link users directly to community resources and show community activity

Landing page for:

 - Forums
 - IRC
 - Articles, apps, and plugins (Bithub)
 - Twitter (tweet, follow)
 - Issues (report issues)
 - GitHub (fork follow)

## Download

 - Download button
 - Download builder: customize options, plugins, library
 - CDN links
 - Examples? 