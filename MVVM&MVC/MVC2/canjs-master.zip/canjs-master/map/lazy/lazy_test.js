steal("can/map/lazy/nested_reference_test.js", "can/map/lazy/map_test.js",
	"can/map/lazy/observe_test.js", "can/map/lazy/list_test.js", "steal-qunit", function () {
	//
});
