@function can.Map.setter.setValue setValue

Sets the setter attributes value.

@param {*} value The value

@body

## Use

Call a [can.Map.setter setter's] `setValue` callback update
the value of the attribute.
