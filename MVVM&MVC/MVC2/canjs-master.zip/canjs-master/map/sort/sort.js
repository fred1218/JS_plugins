steal('can/list/sort', function (sortPlugin) {
	return sortPlugin;
});