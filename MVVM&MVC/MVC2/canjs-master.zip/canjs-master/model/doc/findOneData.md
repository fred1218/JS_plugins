@typedef {function} can.Model.findOneData findOneData

@param {Object} params
@return {can.Deferred} A deferred
