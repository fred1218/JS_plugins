@hide
@function can.Model.setup
@parent can.Model.static

Configures