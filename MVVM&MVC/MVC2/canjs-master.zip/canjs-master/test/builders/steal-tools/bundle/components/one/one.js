import tmpl from "./one.stache!";


