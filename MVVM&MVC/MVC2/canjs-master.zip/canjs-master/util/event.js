steal('can/util/can.js', 'can/event', function (can) {
	// # can/util/event
	// This imports can/event for API compatibility.
	return can;
});
