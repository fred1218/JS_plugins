@page can.events
@parent can.util

CanJS adds the following DOM events to the base library:

 - [can.events.attributes attributes] - called when an element's attributes are changed
 - [can.events.inserted inserted] - called when an element is inserted into the document
 - [can.events.removed removed] - called when an element is removed from the document

 

