@property {String} can.fixture.rootUrl rootUrl
@parent can.fixture

`can.fixture.rootUrl` contains the root URL for fixtures to use.
If you are using StealJS it will use the Steal root
URL by default.