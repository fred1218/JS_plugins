steal('can/model', 'can/control/route', 'can/view/ejs');
