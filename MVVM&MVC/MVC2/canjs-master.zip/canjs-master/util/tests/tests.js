steal('../string/string', '../inserted/inserted', '../attr/attr', '../array/each');
