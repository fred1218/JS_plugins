steal('../string/string_test',  '../inserted/inserted_test', '../attr/attr_test', '../array/each_test');
