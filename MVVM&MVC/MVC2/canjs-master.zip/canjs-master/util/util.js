// comments are in func.js for documentation purposes.
steal('can/util/jquery', function (can) {
	return can;
});
