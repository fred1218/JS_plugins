# img
Add your image files to this directory.
[Favicon Cheat Sheet](https://github.com/audreyr/favicon-cheat-sheet)

Apple Touch Icons:
  * PNG files
  * Name: apple-touch-icon-*.png
  * Sizes:
    * 57x57
    * 72x72
    * 114x114
    * 120x120
    * 144x144
    * 152x152

Windows 8 Start Screen Tile:
  * PNG file
  * Name: ms-touch-icon.png
  * Sizes:
    * 144x144

Favicon:
  * ICO file with multiple images
  * Name: favicon.ico
  * Sizes:
    * 16x16
    * 32x32
    * 48x48
