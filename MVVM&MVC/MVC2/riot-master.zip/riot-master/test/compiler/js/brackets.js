riot.tag('tag', '<p attr="${ thing }">\\${ thing \\}</p>', function(opts) {
  this.x = 'ok'

});