var outer = 'js'

riot.tag('tag', ' <p></p>', function(opts) {

  if (a > b) {  }

});

riot.tag('2nd', '<p></p>', function(opts) {

  this.foo = function() {

    this.update()
  }.bind(this);

});

var after = 'js2 <html>'