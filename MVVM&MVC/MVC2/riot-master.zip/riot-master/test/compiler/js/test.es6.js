riot.tag('es6', '<h3>{ test }</h3>', function(opts) {

var type = 'JavaScript';
this.test = 'This is ' + type;
});