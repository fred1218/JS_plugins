riot.tag('sample', '<p>test { value }</p>', function(opts) {this.value = 'sample';

});