# riotjs-dbmonster
Yet another 'dbmonster' demo, using [riot.js](https://github.com/muut/riotjs)

This demo is based on the ractive dbmonster demo. Other dbmonster versions I've found so far:

* [Ractive](http://www.rich-harris.co.uk/ractive-dbmonster)
* [React](http://run.plnkr.co/plunks/Wwgjjpl9NHMO5Nd1TUyN)
* [Ember](https://dbmonster.firebaseapp.com)
* [Underscore/Backbone](http://jashkenas.github.io/dbmonster)
* [Paperclip](http://paperclip-dbmonster.herokuapp.com)
