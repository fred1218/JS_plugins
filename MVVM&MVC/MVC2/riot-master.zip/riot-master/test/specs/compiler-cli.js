describe('Compiler CLI', function() {

  require('./compiler/html')
  require('./compiler/scoped-css')
  require('./compiler/riotjs')
  require('./compiler/tag')

})
