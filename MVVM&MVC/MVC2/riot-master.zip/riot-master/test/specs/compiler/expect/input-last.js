riot.tag('test', '<input type="text">', function(opts) {

  echo('hey')

});