function foo() {
  alert('1 < 2')
}

var FOO = {
  bar: 1 > 2
}

if (1 < 2) { }

riot.tag('my-tag', '<h2>Hello</h2>', function(opts) {

});

if (1 > 2) { }

riot.tag('my-tag2', '<h2>World</h2>', function(opts) {

});