
  this.click = function(e) {
    alert('Hello!')
  }.bind(this);

  
  this.change = function(e) {
    alert('Hello!')
  }.bind(this);
