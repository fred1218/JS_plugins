  var foo = {
    get bar() {
      return 'baz'
    }
  }
