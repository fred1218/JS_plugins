  this.click = function(e) {
    alert('Hello!')
  }.bind(this);
