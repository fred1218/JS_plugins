  this.myObj = {
    foo: 'bar',
    baz: 'foo'
  }
