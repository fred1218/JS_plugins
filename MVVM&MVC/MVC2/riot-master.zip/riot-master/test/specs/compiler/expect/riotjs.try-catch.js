  try {
    alert('Hello!')
  }
  catch(exception) {
    alert('Oops!')
  }
