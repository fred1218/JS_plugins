riot.tag('same', '', function(opts) {
  var foo

});

riot.tag('another', '<same></same>', function(opts) {

});