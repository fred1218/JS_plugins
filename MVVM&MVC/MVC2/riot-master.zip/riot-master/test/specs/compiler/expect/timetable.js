riot.tag('timetable', '<timer start="10"></timer> <timer start="20"></timer> <timer start="30"></timer>', function(opts) {

});