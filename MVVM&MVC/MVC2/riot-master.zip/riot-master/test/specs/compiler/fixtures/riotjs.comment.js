  //THIS IS A LINE COMMENT
  click (e) {
    alert('Hello!')
  }

  /* THIS
   * IS
   * A
   * BLOCK
   * COMMENT */
  change (e) {
    alert('Hello!')
  }
