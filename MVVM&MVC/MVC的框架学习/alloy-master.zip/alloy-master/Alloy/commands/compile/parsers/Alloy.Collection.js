exports.parse = function(node, state) {
	return require('./Alloy.Abstract._BackboneClass').parse(node, state);
};