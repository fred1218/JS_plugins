exports.parse = function(node, state) {
	return require('./default').parse(node, state);
};
