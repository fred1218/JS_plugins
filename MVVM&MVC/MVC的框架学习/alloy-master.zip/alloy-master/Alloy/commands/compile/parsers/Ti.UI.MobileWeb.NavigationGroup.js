exports.parse = function(node, state) {
	return require('./Ti.UI.iPhone.NavigationGroup').parse(node, state);
};