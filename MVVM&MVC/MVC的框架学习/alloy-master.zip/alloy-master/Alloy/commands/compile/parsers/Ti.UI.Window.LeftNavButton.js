exports.parse = function(node, state) {
	return require('./Ti.UI.Window._ProxyProperty').parse(node, state);
};