exports.parse = function(node, state) {
	return require('./Ti.UI.Windows.AppBarButton').parse(node, state);
};
