exports.parse = function(node, state) {
	return require('./Ti.UI.ButtonBar').parse(node, state);
};