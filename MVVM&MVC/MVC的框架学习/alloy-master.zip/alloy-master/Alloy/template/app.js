/**
 * Alloy for Titanium by Appcelerator
 * This is generated code, DO NOT MODIFY - changes will be lost!
 * Copyright (c) 2012 by Appcelerator, Inc.
 */
var Alloy = require('alloy'),
	_ = Alloy._,
	Backbone = Alloy.Backbone;

__MAPMARKER_ALLOY_JS__
Alloy.createController('index');