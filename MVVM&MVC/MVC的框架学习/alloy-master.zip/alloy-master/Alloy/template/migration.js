migration.up = function(migrator) {
<%= up %>
};

migration.down = function(migrator) {
<%= down %>
};
