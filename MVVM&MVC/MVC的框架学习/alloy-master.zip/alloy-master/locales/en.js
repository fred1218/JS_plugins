{
	"Project not an Alloy app, continuing": "Project not an Alloy app, continuing",
	"Found Alloy app in %s": "Found Alloy app in %s",
	"Alloy compiler failed": "Alloy compiler failed",
	"Executing Alloy compile: %s": "Executing Alloy compile: %s",
	"Alloy compiler completed successfully": "Alloy compiler completed successfully"
}