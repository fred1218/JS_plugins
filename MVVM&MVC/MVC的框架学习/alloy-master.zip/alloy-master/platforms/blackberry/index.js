module.exports = new (require('../base.js'))({
	platform: 'blackberry'
});