module.exports = new (require('../base.js'))({
	platform: 'ios',
	titaniumFolder: 'iphone',
	name: 'iPhone OS',
	osname: ['ipad','iphone']
});