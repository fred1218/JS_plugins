module.exports = new (require('../base.js'))({
	platform: 'windows',
	alloyFolder: 'windows',
	titaniumFolder: 'windows',
	name: 'Windows Phone',
	osname: 'windows'
});