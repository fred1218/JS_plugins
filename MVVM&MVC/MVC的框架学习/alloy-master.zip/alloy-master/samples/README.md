Sample applications that Studio users can import as new projects.

* mapping - Map-based application. Will require Google Maps key to run on Android.
* rss - An RSS reader
* todo - A to-do list tracking app