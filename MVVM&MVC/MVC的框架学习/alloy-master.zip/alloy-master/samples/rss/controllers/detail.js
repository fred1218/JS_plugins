exports.setArticle = function(articleUrl) {
	$.web.url = articleUrl;
};