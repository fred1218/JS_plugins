var args = arguments[0] || {};

$.row.articleUrl = args.articleUrl;
$.image.image = args.image;
$.date.text = args.date;
$.title.text = args.title;