New Alloy-based app templates used by Studio.

* default - The default, one-window, app template. Essentially, this is the "Hello World" of Alloy apps.
* two_tabbed - Tab-based app with two tabs.