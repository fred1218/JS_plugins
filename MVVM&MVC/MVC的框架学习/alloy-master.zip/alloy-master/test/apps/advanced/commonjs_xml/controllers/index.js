function doClick(e) {
	alert('clicked');
}

$.index.open();