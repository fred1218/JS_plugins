Alloy.Globals.scrollTop = (OS_IOS && parseInt(Ti.Platform.version, 10) >= 7) ? 20 : 0;
