var args = arguments[0] || {};
$.label.text = args.title || '';
$.button.visible = args.hideButton !== 'true';