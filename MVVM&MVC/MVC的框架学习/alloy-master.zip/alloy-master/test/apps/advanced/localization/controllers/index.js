$.viaController.text = L('hello_world');

$.index.open();