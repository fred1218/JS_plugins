if (!OS_IOS && !OS_ANDROID) {
	alert('This test app is currently only supported on iOS and Android');
} else {
	Alloy.Globals.data = {
		'Juan Manuel Marquez': {
			nickname: 'Dinamita',
			age: 39,
			height: "5' 7\"",
			weight: '142',
			record: '55-6-1'
		},
		'Manny Pacquiao': {
			nickname: 'Pac-Man',
			age: 34,
			height: "5' 7\"",
			weight: '144',
			record: '54-5-2'
		},
		'Floyd Mayweather Jr.': {
			nickname: 'Money',
			age: 35,
			height: "5' 8\"",
			weight: '146',
			record: '43-0'
		},
		'Sergio Martinez': {
			nickname: 'Maravilla',
			age: 37,
			height: "5' 10\"",
			weight: '158',
			record: '50-2-2'
		},
		'Nonito Donaire': {
			nickname: 'The Filipino Flash',
			age: 30,
			height: "5' 6\"",
			weight: '121',
			record: '31-1'
		}
	};
}