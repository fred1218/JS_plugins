if (!OS_IOS) {
	alert('This app is only supported on iOS');
}