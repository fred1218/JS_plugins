Alloy.Collections.dummy = new Backbone.Collection();
Alloy.Collections.dummy.add([
	{ title: 'row 1' },
	{ title: 'row 2' },
	{ title: 'row 3' },
	{ title: 'row 4' },
	{ title: 'row 5' }
]);