Alloy.Globals.buttonColor = OS_IOS && parseInt(Ti.Platform.version.split('.')[0], 10) >= 7 ? '#eee' : '#111';
