function alertTitle(e) {
	alert(e.source.title);
}