function alertAction(e) {
	alert('action clicked');
}