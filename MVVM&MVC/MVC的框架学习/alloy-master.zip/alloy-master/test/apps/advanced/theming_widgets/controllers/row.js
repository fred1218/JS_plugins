var args = arguments[0] || {};
$.row.title = args.title;