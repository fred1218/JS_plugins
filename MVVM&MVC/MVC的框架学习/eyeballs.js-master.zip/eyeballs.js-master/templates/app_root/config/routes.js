o_O.routes.draw(function(map){
  // Use the routes file to configure hashtag-navigation routes
  // that trigger particular controller actions

  // For Example, to route links pointing to "#/" to HomeController.index():
  // map.match('/',{to: 'home#index'});
})