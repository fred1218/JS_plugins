o_O('<%= name.capitalize -%>Controller', {
  
})