o_O('<%= name.capitalize %>', function(){
  
})