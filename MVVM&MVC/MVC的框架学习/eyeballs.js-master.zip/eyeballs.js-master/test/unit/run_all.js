var current_test = document.location.pathname.split('/')[document.location.pathname.split('/').length - 1];
var index = test_files.indexOf(current_test);