// loads all of jquerymx's command line tests

//load("jquery/download/test/run.js");

load('jquery/view/test/compression/run.js');

load("jquery/generate/test/run.js");

