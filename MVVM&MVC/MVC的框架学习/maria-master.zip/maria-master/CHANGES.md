1.2.0 - [date]
--------------
* add `moreUIActions` option to `maria.ElementView.subclass`
* expose `maria.find` and `maria.findAll` utility functions

1.1.0 - July 25, 2013
---------------------
* development builds in maria-debug.js and maria-amd-debug.js
* constructor functions have a superConstructor property

1.0.0 - June 1, 2013
--------------------
* first stable release
