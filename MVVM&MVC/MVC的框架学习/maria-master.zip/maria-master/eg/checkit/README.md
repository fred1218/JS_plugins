Open src/index.html in a web browser.
