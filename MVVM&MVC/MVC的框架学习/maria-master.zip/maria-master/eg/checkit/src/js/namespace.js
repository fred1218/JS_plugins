var checkit = {};
