checkit.TodoTemplate =
    '<li class="Todo">' +
        '<span class="checkbox"></span> ' +
        '<span class="content"></span>' +
    '</li>';