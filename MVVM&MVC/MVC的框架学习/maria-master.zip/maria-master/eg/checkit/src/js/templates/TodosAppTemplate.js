checkit.TodosAppTemplate =
    '<div class="TodosApp"></div>';
