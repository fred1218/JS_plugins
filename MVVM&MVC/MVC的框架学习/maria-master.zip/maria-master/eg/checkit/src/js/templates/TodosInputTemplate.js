checkit.TodosInputTemplate =
    '<div class="TodosInput">' +
        '<input class="content" placeholder="What needs to be done?" type="text">' +
        '<span class="instructions">Press enter to add this task.</span>' +
    '</div>';
