checkit.TodosListTemplate =
    '<ul class="TodosList"></ul>';
