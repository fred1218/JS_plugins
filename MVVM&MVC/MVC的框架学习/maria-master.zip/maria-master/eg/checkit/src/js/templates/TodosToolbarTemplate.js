checkit.TodosToolbarTemplate =
    '<ul class="TodosToolbar">' +
        '<li><span class="allCheckbox"></span></li> ' +
        '<li><input class="deleteDone" type="button" value="delete complete"></input></li>' +
    '</ul>';
