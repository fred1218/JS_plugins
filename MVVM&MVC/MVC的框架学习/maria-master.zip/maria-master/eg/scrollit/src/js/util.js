scrollit.escapeHTML = function(html) {
    return html.replace('&', '&amp;').replace('<', '&lt;')
};
