Open src/index.html in a web browser.

This example is largely influenced by Colin Moock's book "Essential ActionScript 2.0".
