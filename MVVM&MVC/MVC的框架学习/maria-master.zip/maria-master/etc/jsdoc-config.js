{
    "plugins": [ "plugins/markdown" ]
}
