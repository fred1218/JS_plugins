/**

Add an event listener.

See evento.on for description.

*/
maria.on = evento.on;

/**

Remove an event listener.

See evento.off for description.

*/
maria.off = evento.off;

/**

Purge an event listener of all its subscriptions.

See evento.purge for description.

*/
maria.purge = evento.purge;
