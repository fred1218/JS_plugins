/** 

Find an element matching a CSS selector.

See grail.find for description.

*/
maria.find = grail.find;

/**

Find all elements matching a CSS selector.

See grail.findAll for description.

*/
maria.findAll = grail.findAll;
