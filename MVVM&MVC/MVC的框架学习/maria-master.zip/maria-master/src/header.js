/**
@license
Maria 1.1.0
Copyright (c) 2013, Peter Michaux
All rights reserved.
Licensed under the Simplified BSD License.
http://peter.michaux.ca/downloads/maria/1.1.0/LICENSE
*/
