/**

Root namespace

@namespace

*/
var maria = {};

/* DEBUG BEGIN */
// Help older browsers without the `console` host object.
var console = console || {};
console.log = console.log || function() {};
console.warn = console.warn || function() {};
console.error = console.error || function() {};
/* DEBUG END */
