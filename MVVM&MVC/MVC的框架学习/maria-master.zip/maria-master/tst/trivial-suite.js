(function() {

    buster.testCase('Trival Suite', {

        "test trivial": function() {
            assert(true);
        }

    });

}());
