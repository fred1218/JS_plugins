## Userconfig Hook

This hook loads app-level user configuration using the moduleloader hook (from the config directory located at `sails.config.paths.config`) It is always loaded first.

##### Contributing to this hook
Not a good place to jump in right now.  Please tweet @mikermcneil before working on this part!
