//========================================
//
//    	事件绑定处理
//
//========================================
Aaron.register('directives-on', function() {

	return {

		bind: function() {

		},

		undate: function() {

		},

		unbind: function() {

		}
	}

});




