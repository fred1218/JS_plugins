前端MVVM框架设计及实现
======================

11月结束jQuery教程，启动MVVM框架


分析流程</br>

  MVVM框架设计及实现（一）: 实现最基本监控属于及双向绑定</br>

  MVVM框架设计及实现（二）: 指令</br>
  
  MVVM框架设计及实现（三）: 重构代码，加入AMD组织结构</br>

  

分析博客</br>
  
  http://www.cnblogs.com/Aaronjs/</br>
