(function () {
	var toExport = {hehe: 'I did it, so simple'};
	html.module('testModule', toExport);
})()