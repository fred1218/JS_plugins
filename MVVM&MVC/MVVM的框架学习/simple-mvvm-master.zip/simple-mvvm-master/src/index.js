var compile = require('./compile');

window.$compile = compile;