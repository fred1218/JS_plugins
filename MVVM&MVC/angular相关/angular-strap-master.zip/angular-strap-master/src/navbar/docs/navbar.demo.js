'use strict';

angular.module('mgcrea.ngStrapDocs')

.controller('NavbarDemoCtrl', function($scope, $location) {
  $scope.$location = $location;

});
