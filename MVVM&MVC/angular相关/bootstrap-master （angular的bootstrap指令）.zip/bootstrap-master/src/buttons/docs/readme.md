There are two directives that can make a group of buttons behave like a set of checkboxes, radio buttons, or a hybrid where radio buttons can be unchecked.

In order to be able to uncheck the currently selected radio button, one can use the `uncheckable` attribute in tandem with `btn-radio`.
