
angular.module('_name_Demo1', ['ngMaterial'])

.controller('AppCtrl', function($scope) {


});
