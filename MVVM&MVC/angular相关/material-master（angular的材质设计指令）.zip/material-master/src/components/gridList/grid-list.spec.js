
describe('md-grid-list', function() {

  beforeEach(module('ngAria'));
  beforeEach(module('material.components.gridList'));

  it('should ', function() {

  });

});
