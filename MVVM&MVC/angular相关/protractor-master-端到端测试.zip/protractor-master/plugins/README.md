Please see [the plugin documentation](../docs/plugins.md)
