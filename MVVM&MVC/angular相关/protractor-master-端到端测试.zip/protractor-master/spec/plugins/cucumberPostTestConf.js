exports.config = require('./postTestConfTemplate')('cucumber');
