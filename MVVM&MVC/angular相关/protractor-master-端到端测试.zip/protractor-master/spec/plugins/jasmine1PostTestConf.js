exports.config = require('./postTestConfTemplate')('jasmine');
