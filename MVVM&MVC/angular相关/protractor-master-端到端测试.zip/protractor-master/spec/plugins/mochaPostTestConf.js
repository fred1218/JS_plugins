exports.config = require('./postTestConfTemplate')('mocha');
