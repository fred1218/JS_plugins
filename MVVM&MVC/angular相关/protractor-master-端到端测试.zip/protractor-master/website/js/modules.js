'use strict';

angular.module('protractorApp', ['ngRoute']);
