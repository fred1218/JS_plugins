define([/* TODO: add dependencies of this page */], function () {

    var Home = {
        init: function () {
            /* TODO: preparation before the page's template is rendered */
        },
        dispose: function () {
            /* TODO: properly dispose this page to prevent memory leaks and UI leftovers
              (data that will no longer be used, event listeners, knockout manual subscriptions, etc.) */
        },
        controllers: {
            '/': function () {}
        }
    };

    return Home;

});
