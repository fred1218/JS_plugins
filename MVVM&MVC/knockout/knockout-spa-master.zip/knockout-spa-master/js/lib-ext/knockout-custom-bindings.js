define(['Knockout.CustomBindings.Core'/* TODO: add other ko binding modules as needed */], function (ko) {
    return ko;
});
