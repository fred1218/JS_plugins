define(['Knockout.Raw', 'Knockout.AMDHelpers', 'Knockout.CustomBindings'], function (ko) {
    return ko;
});
