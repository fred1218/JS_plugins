define({
    /* TODO: add app localized resources for this locale */
});
