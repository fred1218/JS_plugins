define({
    /* TODO: add app localized strings for this locale */
});
