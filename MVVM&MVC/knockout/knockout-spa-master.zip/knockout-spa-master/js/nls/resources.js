define({
    "root": {
        /* TODO: add app localized resources */
    },
    "en-gb": true
});
