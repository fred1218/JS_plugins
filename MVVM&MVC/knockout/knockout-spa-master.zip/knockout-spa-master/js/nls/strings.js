define({
    "root": {
        "error.403": "Forbidden",
        "error.404": "Not Found",
        "error.500": "Internal Server Error"
        /* TODO: add app localized strings */
    },
    "en-gb": true
    /* TODO: add other supported locales */
});
