# Changelog

### 2.1.1

* Publish `dist/` on npm

### 2.1.0

* Add flux-utils which include four main base classes: `Store`, `ReduceStore`, `MapStore`, `Container`
* Add flux-utils example and documentation
* Upgrade build script
* Publish a minified version of `Flux` in `dist/`
* Add flow types to `Dispatcher`
