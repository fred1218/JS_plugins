---
id: immutable-ko-KR
title: ImmutableJS – 불변 데이터
layout: docs
category: Complementary
permalink: http://facebook.github.io/immutable-js/
next: jest-ko-KR
lang: ko-KR
---
