---
id: jest-ko-KR
title: Jest – 단위 테스팅
layout: docs
category: Complementary
permalink: http://facebook.github.io/jest/
lang: ko-KR
---
