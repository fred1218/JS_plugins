---
id: conferences-ko-KR
title: 컨퍼런스들
permalink: conferences-ko-KR.html
prev: thinking-in-react-ko-KR.html
next: videos-ko-KR.html
---

### React.js Conf 2015
1월 28일 & 29일

[웹사이트](http://conf.reactjs.com/) - [스케줄](http://conf.reactjs.com/schedule.html) - [비디오들](https://www.youtube-nocookie.com/playlist?list=PLb0IAmt7-GS1cbw4qonlQztYV1TAW0sCr)

<iframe width="650" height="315" src="//www.youtube-nocookie.com/embed/KVZ-P-ZI6W4?list=PLb0IAmt7-GS1cbw4qonlQztYV1TAW0sCr" frameborder="0" allowfullscreen></iframe>

### ReactEurope 2015
7월 2일 & 3일

[웹사이트](http://www.react-europe.org/) - [스케줄](http://www.react-europe.org/#schedule)
