---
id: flux-todo-list-it-IT
title: Tutorial TodoMVC Flux
permalink: flux-todo-list-it-IT.html
---

Questa pagina è stata spostata sul sito di Flux. [Leggila qui](https://facebook.github.io/flux/docs/todo-list.html).
