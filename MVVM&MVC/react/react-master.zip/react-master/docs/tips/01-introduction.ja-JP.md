---
id: introduction-ja-JP
title: イントロダクション
layout: tips
permalink: introduction-ja-JP.html
next: inline-styles-ja-JP.html
---

Reactのtipsのセクションでは、あなたの質問の多くに答えられたり、はまりそうな罠に対する注意を行う適当な大きさの情報を提供します。

## コントリビューティング

[Reactのリポジトリ](https://github.com/facebook/react)に[現在のtips](https://github.com/facebook/react/tree/master/docs)の記事のスタイルに沿った形でプルリクエストを投げてください。プルリクエストを投げる前にレビューが必要な場合は[freenodeの #reactjs チャンネル](irc://chat.freenode.net/reactjs)や[discuss.reactjs.org フォーラム](https://discuss.reactjs.org/)で助けを求めることができます。
