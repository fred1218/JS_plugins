---
id: references-to-components
title: References to Components
layout: tips
permalink: references-to-components.html
prev: expose-component-functions.html
next: children-undefined.html
---

This page has moved to: [refs](/react/docs/more-about-refs.html).
