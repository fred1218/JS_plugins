All notable changes are described on the [Releases](https://github.com/rackt/react-redux/releases) page.
