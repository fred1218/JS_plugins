## Introduction

* [Motivation](Motivation.md)
* [Three Principles](ThreePrinciples.md)
* [Prior Art](PriorArt.md)
* [Ecosystem](Ecosystem.md)
* [Examples](Examples.md)
