//# sourceMappingURL=IAnalogNeedle.js.map
