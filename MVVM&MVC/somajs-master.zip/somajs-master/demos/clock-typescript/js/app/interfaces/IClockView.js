///<reference path='../vo/time.ts'/>
//# sourceMappingURL=IClockView.js.map
