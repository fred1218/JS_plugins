///<reference path='../vo/time.ts'/>
//# sourceMappingURL=ITimer.js.map
