var clock;
(function (clock) {
    var TimeVO = (function () {
        function TimeVO() {
        }
        return TimeVO;
    })();
    clock.TimeVO = TimeVO;
})(clock || (clock = {}));
//# sourceMappingURL=time.js.map
