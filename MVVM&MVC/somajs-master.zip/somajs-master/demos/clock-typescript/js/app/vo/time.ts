module clock {

	export class TimeVO {

		public now:Date;
		public hours:number;
		public minutes:number;
		public seconds:number;
		public milliseconds:number;
		public day:number;
		public date:number;
		public month:number;

	}

}