(function (soma, infuse) {

	'use strict';

	soma.version = '2.1.1';
