# Stapes.js <sup>*</sup>
### (*) the Javascript MVC microframework that does *just enough*

Full documentation available here:

[http://hay.github.io/stapes/](http://hay.github.io/stapes/)
