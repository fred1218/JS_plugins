var createElement = require("./vdom/create-element.js")

module.exports = createElement
