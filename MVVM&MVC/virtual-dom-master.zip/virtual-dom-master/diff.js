var diff = require("./vtree/diff.js")

module.exports = diff
