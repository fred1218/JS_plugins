var patch = require("./vdom/patch.js")

module.exports = patch
