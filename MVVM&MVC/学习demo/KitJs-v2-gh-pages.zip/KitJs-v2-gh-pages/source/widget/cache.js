define('widget/cache', [ 'widget/Cache/L2Cache' ], function(L2Cache) {
	return new L2Cache();
})