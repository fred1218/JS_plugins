define([ 'widget/messageBox/messageBox' ], function(message) {
	return message;
})