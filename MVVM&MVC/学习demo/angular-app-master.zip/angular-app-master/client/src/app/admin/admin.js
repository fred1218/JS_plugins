angular.module('admin', ['admin-projects', 'admin-users']);
