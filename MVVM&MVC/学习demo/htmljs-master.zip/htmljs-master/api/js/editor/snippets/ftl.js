define('ace/snippets/ftl', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "ftl";

});
