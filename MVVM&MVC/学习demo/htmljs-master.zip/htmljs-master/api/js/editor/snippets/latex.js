define('ace/snippets/latex', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "latex";

});
