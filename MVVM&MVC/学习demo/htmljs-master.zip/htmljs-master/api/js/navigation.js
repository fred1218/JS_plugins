html.router('#tryit?section=:section', function(section) {
    console.log(section);
});