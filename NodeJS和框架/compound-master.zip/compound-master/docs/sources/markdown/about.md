
Documentation is maintained by [@1602 (Anatoliy Chakkaev)](http://twitter.com/1602) and [@rattazong (Sascha Gehlich)](http://twitter.com/rattazong).

CompoundJS is licensed under the [MIT License](http://www.opensource.org/licenses/mit-license.php). Documentation is licensed under [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/).

The CompoundJS and JugglingDB projects are free, but you can leave a tip here:

<form style="text-align: center" action="https://www.paypal.com/cgi-bin/webscr" method="post">
  <input type="hidden" name="cmd" value="_s-xclick">
  <input type="hidden" name="hosted_button_id" value="J3JJDYJW78LEJ">
  <input type="image" style="box-shadow: none; -webkit-box-shadow: none; padding: 0; border: 0; width: 147px; height: 47px;" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
  <img alt="" border="0" src="https://www.paypalobjects.com/ru_RU/i/scr/pixel.gif" width="1" height="1">
</form>