before('protect from forgery', function () {
  protectFromForgery('{{ SECRET }}');
});
