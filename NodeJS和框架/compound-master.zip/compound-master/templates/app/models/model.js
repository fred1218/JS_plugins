module.exports = function (compound, {{ MODELNAME }}) {
  // define {{ MODELNAME }} here
};