module.exports = 
  { "development":
    { "driver":   "memory"
    }
  , "test":
    { "driver":   "memory"
    }
  , "production":
    { "driver":   "memory"
    }
  };
