var {{ MODELNAME }} = describe('{{ MODELNAME }}', function () {
{{ PROPERTIES }}
    set('restPath', pathTo.{{ models }});
});
