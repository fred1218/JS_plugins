
/*
  Add your application's coffee-script code here
*/


(function() {



}).call(this);