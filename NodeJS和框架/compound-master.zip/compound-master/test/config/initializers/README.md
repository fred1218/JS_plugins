TEST
====

File who not appear in initializer