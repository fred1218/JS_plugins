module.exports = function(compound) {
  compound.isInitialize = true;
}
