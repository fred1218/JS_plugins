module.exports = function(compound) {
    compound.app.set('hello', 'world');
};
