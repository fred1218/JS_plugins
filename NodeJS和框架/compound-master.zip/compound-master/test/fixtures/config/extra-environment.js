module.exports = function(compound) {
    compound.app.set('foo', 'bar');
};
