# total.js examples

> Examples have a new repository: <https://github.com/totaljs/examples>.

__Please support total.js on GitHub with the star button.__
