framework.config.isDefinition = true;
framework.resize('/*.jpg', '50%');
framework.merge('/merge.js', '/js/test.js', 'file.txt');
framework.map('/fet.txt', framework.path.public('file.txt'));