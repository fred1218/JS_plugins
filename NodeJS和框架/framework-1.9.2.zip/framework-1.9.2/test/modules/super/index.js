exports.id = 'supermodule';
exports.ok = true;