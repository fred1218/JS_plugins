exports.hello = function() {
	return 'world';
};