exports.id = 'test';
exports.url = 'isomorphic.js';

exports.price = function(count) {
    return count * 1.20;
};