var a = 1 + 1 + 1;
console.log( a );