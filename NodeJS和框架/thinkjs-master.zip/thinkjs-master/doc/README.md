## 文档

详细文档请见 <http://thinkjs.org/doc.html>