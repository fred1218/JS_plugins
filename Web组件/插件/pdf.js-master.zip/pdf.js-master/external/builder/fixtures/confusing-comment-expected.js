'use strict';
var i = 0;
while(i-->0) {
}
