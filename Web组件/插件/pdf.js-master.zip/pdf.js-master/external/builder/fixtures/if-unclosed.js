'use strict';
//#if TRUE
var a;
