<?php
	$url = "dtGrid/doc/index.html";
	Header("Location: $url");
?>