<?php

class Sort {
	
	/**
	 * 字段
	 */
	public $field;
	
	/**
	 * 排序逻辑
	 */
	public $logic;
	
}
?>