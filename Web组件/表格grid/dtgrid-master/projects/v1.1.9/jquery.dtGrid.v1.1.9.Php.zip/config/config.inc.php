<?php
	$config['dbhost'] = 'localhost:3306';
	$config['dbuser'] = 'root';
	$config['dbpass'] = 'root';
	$config['dbname'] = 'destiny_grid';
?>