<?php

class Condition {

	/**
	 * 左括号
	 */
	public $leftParentheses;
	
	/**
	 * 字段名称
	 */
	public $field;
	
	/**
	 * 条件
	 */
	public $condition;
	
	/**
	 * 值
	 */
	public $value;
	
	/**
	 * 右括号
	 */
	public $rightParentheses;
	
	/**
	 * 查询逻辑
	 */
	public $logic;
	
}
?>