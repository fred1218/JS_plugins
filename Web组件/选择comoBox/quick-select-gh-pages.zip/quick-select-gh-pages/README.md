# Quick[select]

See [here](http://quick-select.eggbox.io/) for more info.