---

## 感谢

最初的灵感来自 [Angry Birds of JavaScript- Green Bird: Mocking Introduction](http://www.elijahmanor.com/angry-birds-of-javascript-green-bird-mocking/)，语法参考了 [mockJSON](https://github.com/mennovanslooten/mockJSON)，随机数据参考了 [Chance.js](http://chancejs.com/)。

<!-- 灵感来自 [Elijah Manor])(http://elijahmanor.com/) 的系列博文 [Angry Birds of JavaScript Series](http://www.elijahmanor.com/angry-birds-of-javascript-series/) 中的 [Angry Birds of JavaScript- Green Bird: Mocking Introduction](http://www.elijahmanor.com/angry-birds-of-javascript-green-bird-mocking/) -->