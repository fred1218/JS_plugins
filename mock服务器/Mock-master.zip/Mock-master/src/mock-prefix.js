/*!
    Mock - 模拟请求 & 模拟数据
    https://github.com/nuysoft/Mock
    墨智 nuysoft@gmail.com
*/
(function(undefined) {
	var Mock = {
		version: '0.1.9',
		_mocked: {}
	}