module.exports = function(imitator) {
    imitator(/\/.*/, 'base host');
}

