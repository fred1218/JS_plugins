test("vapor", function() {
  ok(typeof vapor === 'undefined');
});
