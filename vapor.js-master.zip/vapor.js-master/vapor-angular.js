(function(vapor){
  vapor.directive('vapor', function(){
    return {};
  });
}(angular.module('vaporModule', [])));
