$(function(){
  $('#cytoscape').cytoscape(function(){

    // console.profile();

    // profile findNearestElement
    //
    // var r = cy.renderer();
    // for( var i = 0; i < 1000; i++ ){
    //   var x = Math.round( Math.random() * 500 );
    //   var y = Math.round( Math.random() * 500 );

    //   r.findNearestElement(x, y, true);
    // }

    // console.profileEnd();

  });
});