Use side pane for navigation.
