var React = require('react');
var DOM = require('./src/DOM');
module.exports = require('./src/Morearty')(React, DOM);
