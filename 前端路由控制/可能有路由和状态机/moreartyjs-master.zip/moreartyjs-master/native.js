var React = require('react-native');
module.exports = require('./src/Morearty')(React, null);
