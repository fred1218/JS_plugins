"use strict";

var Input = require('./Input.js'),
    currentPointer, // Sort this out for multitouch
    
    TOUCHMOVE = 'touchmove',
    MOUSEMOVE = 'mousemove',

    /*
        Convert event into point
        
        Scrape the x/y coordinates from the provided event
        
        @param [event]: Original pointer event
        @param [boolean]: True if touch event
        @return [object]: x/y coordinates of event
    */
    eventToPoint = function (event, isTouchEvent) {
        var touchChanged = isTouchEvent ? event.changedTouches[0] : false;
        
        return {
            x: touchChanged ? touchChanged.clientX : event.pageX,
            y: touchChanged ? touchChanged.clientY : event.pageY
        };
    },
    
    /*
        Get actual event
        
        Checks for jQuery's .originalEvent if present
        
        @param [event | jQuery event]
        @return [event]: The actual JS event  
    */
    getActualEvent = function (event) {
        return event.originalEvent || event;
    },

    
    /*
        Pointer constructor
    */
    Pointer = function (e) {
        var event = getActualEvent(e), // In case of jQuery event
            isTouch = (event.touches) ? true : false,
            startPoint = eventToPoint(event, isTouch);
        
        this.update(startPoint);
        this.isTouch = isTouch;
        this.bindEvents();
    },
    
    proto = Pointer.prototype = new Input();

/*
    Bind move event
*/
proto.bindEvents = function () {
    this.moveEvent = this.isTouch ? TOUCHMOVE : MOUSEMOVE;
    
    currentPointer = this;
    
    document.documentElement.addEventListener(this.moveEvent, this.onMove);
};

/*
    Unbind move event
*/
proto.unbindEvents = function () {
    document.documentElement.removeEventListener(this.moveEvent, this.onMove);
};

/*
    Pointer onMove event handler
    
    @param [event]: Pointer move event
*/
proto.onMove = function (e) {
    var newPoint = eventToPoint(e, currentPointer.isTouch);
    e = getActualEvent(e);
    e.preventDefault();
    currentPointer.update(newPoint);
};

proto.stop = function () {
    this.unbindEvents();
};

module.exports = Pointer;