var STROKE = 'stroke';

module.exports = {
    opacity: STROKE + '-opacity',
    width: STROKE + '-width',
    miterlimit: STROKE + '-miterlimit'
};