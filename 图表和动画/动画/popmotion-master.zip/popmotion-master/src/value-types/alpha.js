module.exports = {
    defaultProps: {
        min: 0,
        max: 1
    }
};