module.exports = {
    defaultProps: {
        unit: 'deg'
    }
};