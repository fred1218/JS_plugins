module.exports = function (value, prefix) {
    return prefix + '(' + value + ')';
};