module.exports = {
    defaultProps: {
        unit: 'px'
    }
};