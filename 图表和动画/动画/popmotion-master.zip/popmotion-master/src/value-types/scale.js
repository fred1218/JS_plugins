module.exports = {
    defaultProps: {
        init: 1
    }
};