module.exports = function () {
  return { posts: [] }
}
