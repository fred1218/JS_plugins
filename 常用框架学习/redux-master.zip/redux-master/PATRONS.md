# Patrons

The work on Redux was [funded by the community](https://www.patreon.com/reactdx).  
Meet some of the outstanding companies and individuals that made it possible:

* [Webflow](https://webflow.com/)
* [Chess iX](http://www.chess-ix.com/)
* [Herman J. Radtke III](http://hermanradtke.com)
* [Ken Wheeler](http://kenwheeler.github.io/)
* Chung Yen Li
* [Sunil Pai](https://twitter.com/threepointone)
* [Charlie Cheever](https://twitter.com/ccheever)
* [Eugene G](https://twitter.com/e1g)
* [Matt Apperson](https://twitter.com/mattapperson)
* [Jed Watson](https://twitter.com/jedwatson)
* [Sasha Aickin](https://twitter.com/xander76)