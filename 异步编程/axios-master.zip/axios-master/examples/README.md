# axios examples

To run the examples:

1. `git clone git@github.com:mzabriskie/axios.git`
2. `npm install`
3. `grunt build`
4. `npm run examples`
5. [http://localhost:3000](http://localhost:3000)
