[http://bluebirdjs.com/docs/contribute.html](http://bluebirdjs.com/docs/contribute.html)
