---
id: what-about-generators
title: What About Generators?
---

[what-about-generators](unfinished-article)
