module.exports = require('./lib/deferred')
