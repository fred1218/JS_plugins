module.exports = require('./lib/eventproxy');
