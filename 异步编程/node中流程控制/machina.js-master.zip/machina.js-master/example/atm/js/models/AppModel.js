var AppModel = Backbone.Model.extend( {
	title : "Contrived ATM Example"
} );