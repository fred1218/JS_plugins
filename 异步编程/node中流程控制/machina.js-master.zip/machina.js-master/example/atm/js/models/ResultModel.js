var ResultModel = Backbone.Model.extend( {
	defaults : {
		modelType : "result"
	}
} );