/**
 * @description Define the stepify library.
 * @author <a href="mailto:yangdemo@gmail.com">dmyang</a>
 **/

module.exports = require('./lib/Stepify');
