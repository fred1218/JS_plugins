## Deliverables
state.js comprises the following files:
* **state.js:** for use in web pages; include this using the HTML script element.
* **state.min.js:** a minified version of state.js.
* **state.com.js:** for use in node; this is the target file when using ```require("state,js")```.
* **state.com.d.ts:** this a TypeScript declaration file.
