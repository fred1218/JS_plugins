"use strict";

var Wind = require("../../src/wind");
require("../../src/wind-compiler");

require("chai").should();
require("./tests").setupTests(Wind);
