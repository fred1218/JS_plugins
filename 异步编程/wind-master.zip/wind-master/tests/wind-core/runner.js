"use strict";

var Wind = require("../../src/wind-core");
require("chai").should();
require("./tests").setupTests(Wind);