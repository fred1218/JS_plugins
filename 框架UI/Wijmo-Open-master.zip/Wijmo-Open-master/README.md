[Wijmo Open](http://wijmo.com/) - Open Source jQuery UI Widgets
================================

Wijmo is a complete kit of over 40 UI widgets with everything from interactive menus to rich charts. If you know jQuery, you know Wijmo. Complete with documentation and professional support, every widget is hand-crafted and includes premium themes.

If you want to use Wijmo, go to [wijmo.com](http://wijmo.com) to get started. Or visit the [Wijmo Forum](http://wijmo.com/forums/) for discussions and questions.

Wijmo Open is completely free and open source with no limitations. Wijmo Open can be licensed under the [MIT](http://www.opensource.org/licenses/mit-license.html) or [GPL](http://www.opensource.org/licenses/gpl-2.0.php) licenses. 