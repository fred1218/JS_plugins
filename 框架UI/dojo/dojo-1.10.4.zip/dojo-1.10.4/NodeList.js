define(["./query"], function(query){
	// This class is just for documentation purposes, so NodeList shows up well in the API viewer,
	// and to simplify writing API doc for all the methods that take NodeList as a parameter, or return a NodeList.
	return query.NodeList;
});

