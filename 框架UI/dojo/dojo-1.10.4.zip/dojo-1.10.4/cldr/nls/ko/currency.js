define(
//begin v1.x content
{
	"HKD_displayName": "홍콩 달러",
	"CHF_displayName": "스위스 프랑",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "캐나다 달러",
	"HKD_symbol": "HK$",
	"CNY_displayName": "중국 위안화",
	"USD_symbol": "US$",
	"AUD_displayName": "호주 달러",
	"JPY_displayName": "일본 엔화",
	"CAD_symbol": "CA$",
	"USD_displayName": "미국 달러",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "영국령 파운드 스털링",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "유로화"
}
//end v1.x content
);