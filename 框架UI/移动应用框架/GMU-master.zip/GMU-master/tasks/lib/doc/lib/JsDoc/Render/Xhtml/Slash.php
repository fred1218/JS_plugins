<?php

class Text_Wiki_Render_Xhtml_Slash extends Text_Wiki_Render {

function token($options)
{
return $options['text'];
}
}