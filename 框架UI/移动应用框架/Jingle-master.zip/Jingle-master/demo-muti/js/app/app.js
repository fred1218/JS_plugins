$(function () {
    Jingle.launch({
        appType : 'muti'
    });
})
