Contributors
============

The project was originally created by [Kruy Vanna](https://github.com/kruyvanna). Mao Takahashi created the logo and the project name was contributed by Khourn Khemry.

List of code contributors (in no particular order):

* [Mitsunori Kubota](https://github.com/anatoo)
* [Andreas Argelius](https://github.com/argelius)
* [Masahiro Tanaka](https://github.com/masahirotanaka)
* [Rob Taylor](https://github.com/OnsenUI/OnsenUI/graphs/contributors)
* [Andi Pavllo](https://github.com/andipavllo)
* [Yang Li](https://github.com/idealhack)
* [Fran Dios](https://github.com/frankdiox)
* [Hiroshi Shikata](https://github.com/shika22)
* [Marco Andreotti](https://github.com/marqu3z)
* [Ataru Ohto](https://github.com/AtaruOhto)
* [yoshiko](https://github.com/yoshiko-pg)
* [woyehenni](https://github.com/woyehenni)
* [marcel-dancak](https://github.com/marcel-dancak)
* [Tincoboekestij](https://github.com/Tincoboekestij)
* [Atsushi Takayama](https://github.com/atakayama)
* [Shingo Kumagai](https://github.com/shingo-kumagai)
* [David Zumbrunnen](https://github.com/zumbrunnen)
* [Ryohei Ikegami](https://github.com/seanchas116)
* [Dominique Rahm](https://github.com/d3orn)
* [Kon Yuichi](https://github.com/konpyu)
* [zack](https://github.com/zack24q)
* [Adrian Stanecki](https://github.com/astanecki)

Please add yourself if you're not on this list but feel that you should be.
