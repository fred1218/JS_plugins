(function(){
  var app = angular.module('myApp', ['onsen']);
})();
