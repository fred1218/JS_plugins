'use strict';

angular.module('app').factory('ClipboardClients', function() {
  var clients = [];
  return clients;
});
