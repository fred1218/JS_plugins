// code for browserify css module.
'use strict';

angular.module('app').factory('CSSModule', function() {
  return require('css');
});

