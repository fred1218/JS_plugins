# SUI Mobile

## 轻量的UI库

SUI Mobile 是阿里巴巴国际UED团队基于 [Framework7](http://framework7.taobao.org/) 开发的手机H5 UI库。

它的特点是非常轻量，并且能很好兼容 iOS 6.0+ 和 Android 4.0+  的设备。

更多信息请前往 [官网](http://m.sui.taobao.org/)
