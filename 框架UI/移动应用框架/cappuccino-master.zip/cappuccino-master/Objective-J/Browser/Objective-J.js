
var ObjectiveJ = { };

(function (global, exports)
{
#include "Includes.js"
})(window, ObjectiveJ);
