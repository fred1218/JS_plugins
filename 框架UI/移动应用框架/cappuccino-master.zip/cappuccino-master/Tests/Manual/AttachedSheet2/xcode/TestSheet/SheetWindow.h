//
//  SheetWindow.h
//  
//
//  Created by Joe Semolian on 4/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SheetWindow : NSWindow

@end
