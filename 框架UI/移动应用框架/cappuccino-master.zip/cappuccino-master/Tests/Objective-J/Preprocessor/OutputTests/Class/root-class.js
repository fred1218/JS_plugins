
var the_class = objj_allocateClassPair(Nil, "TestClass"),
    meta_class = the_class.isa;

objj_registerClassPair(the_class);
