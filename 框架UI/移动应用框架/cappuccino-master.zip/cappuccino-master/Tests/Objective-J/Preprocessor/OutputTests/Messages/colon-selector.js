
(object==null?null:object.isa.objj_msgSend1(object,":",argument));