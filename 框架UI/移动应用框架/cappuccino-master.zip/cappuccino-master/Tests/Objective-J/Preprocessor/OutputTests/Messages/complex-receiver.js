var a=0;
((___r1=a++<2?small_target:big_target),___r1==null?null:___r1.isa.objj_msgSend0(___r1,"doStuff"));
