
(object==null?null:object.isa.objj_msgSend(object,"label:label2:label3:label4:",argument,argument2,argument3,argument4));
