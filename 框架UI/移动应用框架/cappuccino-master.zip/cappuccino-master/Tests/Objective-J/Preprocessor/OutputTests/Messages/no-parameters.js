CPArray.isa.objj_msgSend0(CPArray,"new");
(object==null?null:object.isa.objj_msgSend0(object,"message"));