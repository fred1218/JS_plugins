CPArray.isa.objj_msgSend1(CPArray,"arrayWithArray:",[]);
(object==null?null:object.isa.objj_msgSend1(object,"label:",argument));