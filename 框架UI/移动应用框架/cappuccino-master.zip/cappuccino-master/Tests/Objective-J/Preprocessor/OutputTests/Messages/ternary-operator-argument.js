
(object==null?null:object.isa.objj_msgSend1(object,"label:",condition?true:false));
(object==null?null:object.isa.objj_msgSend1(object,"label:",condition?true:false));
(object==null?null:object.isa.objj_msgSend1(object,"label:",condition?true:false));
