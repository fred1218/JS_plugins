x=function()
{
    while(false);
    for(;;);
    for(var a in []);
    var b = 3;
}
