f = function(x)
{
    var a = 2,
        b = 1;
    while (a < b);
    for (; ; );
    if (a < b);
    else;
    do
    {
    }
    while (a < b);
}
