x=function(){
return (someIval==null?null:someIval.isa.objj_msgSend0(someIval,"someMethod"));
};
