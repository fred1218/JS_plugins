var name="Martin";
var verb="Was";
var action="Here";
if (4 > 3) var a = 3;