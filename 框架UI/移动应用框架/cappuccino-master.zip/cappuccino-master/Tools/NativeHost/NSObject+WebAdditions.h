//
//  NSObject+WebAdditions.h
//  NativeHost
//
//  Created by Francisco Tolmasky on 11/16/09.
//  Copyright 2009 280 North, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSObject (WebAdditions)

- (BOOL)webBoolValue;

@end
