//
//  XcodeProjectCloser.h
//  XcodeCapp
//
//  Created by Aparajita on 5/12/13.
//  Copyright (c) 2013 Cappuccino Project. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XcodeProjectCloser : NSObject

+ (void)closeXcodeProjectForProject:(NSString *)projectPath;

@end
