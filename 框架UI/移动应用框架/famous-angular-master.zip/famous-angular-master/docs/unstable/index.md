---
layout: "docs_api"
version: "unstable"
versionHref: "/docs/unstable"
path: "api/"
title: Javascript
header_sub_title: Build amazing AngularJS apps with the power of Famo.us
searchable: false
---

# Famo.us/Angular

Famo.us/Angular provides a set of directives and services to integrate Famo.us into your AngularJS app, and to build Famo.us apps using Angular tools.

Explore the API docs for detailed information.
