'use strict';

var ngFameApp = angular.module('famous.angular', []);
