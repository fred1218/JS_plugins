0.4.0 / 2015-07-30
==================
* Stablize
* Performance improvement
* Bug fixes

0.3.0 / 2015-06-01
==================
* Support more mongodb API
* Complete documents
* Cluster support for global mongodb and redis

0.2.0 / 2015-04-11
==================
* Standalone socket server mode
* Performance boost

0.1.0 / 2015-03-13
==================
* First Release

0.0.0 / 2015-02-22
==================
* Draft
