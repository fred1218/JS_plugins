import React from 'react';

class Dashboard extends React.Component {

  render () {
    return (
      <div>
        <h3>Course Dashboard</h3>
      </div>
    );
  }

}

export default Dashboard;

