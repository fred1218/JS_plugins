import React from 'react';

class Messages extends React.Component {

  render () {
    return (
      <div>
        <h2>Messages</h2>
      </div>
    );
  }

}

export default Messages;

