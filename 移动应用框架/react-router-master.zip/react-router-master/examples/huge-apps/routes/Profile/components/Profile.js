import React from 'react';

class Profile extends React.Component {
  render () {
    return (
      <div>
        <h2>Profile</h2>
      </div>
    );
  }
}

export default Profile;

