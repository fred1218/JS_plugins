#!/bin/sh
node_modules/.bin/changelog -t preview -s
