/**
 * @providesModule SiteData
 */

module.exports = {
  version: '0.3.2'
};
