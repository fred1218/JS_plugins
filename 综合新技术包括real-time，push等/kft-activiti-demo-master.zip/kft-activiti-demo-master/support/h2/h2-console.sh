#!/bin/bash
mvn exec:java -Ph2console
