## <a href="#help" name="help">help</a>
> Get help on mod

### Usage

```sh
$ mod help [command]
```






