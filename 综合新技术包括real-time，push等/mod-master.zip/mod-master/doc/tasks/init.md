## <a href="#init" name="init">init</a>
> Generate project skeleton from template

### Usage

```sh
$ mod init <template> [options]
```

### Options

#### template


<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Describe:</b> Destination template</p>
<hr>

#### dest

<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Default:</b> <code>.</code></p>
<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Describe:</b> Target project directory</p>
<hr>







