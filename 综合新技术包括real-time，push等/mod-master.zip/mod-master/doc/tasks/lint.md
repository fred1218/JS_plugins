## <a href="#lint" name="lint">lint</a>
> Validate JavaScript/CSS source

### Usage

```sh
$ mod lint <src>
```

### Options

#### charset

<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Default:</b> <code>utf-8</code></p>
<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Describe:</b> File encoding type</p>
<hr>







