## <a href="#mkdir" name="mkdir">mkdir</a>
> Make a new directory

### Usage

```sh
$ mod mkdir <dest> [options]
```

### Options

#### dest


<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Describe:</b> The name of the directory one wants to create</p>
<hr>

#### mode

<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Default:</b> <code>0777</code></p>
<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Describe:</b> Specify the octal permissions of directory</p>
<hr>







