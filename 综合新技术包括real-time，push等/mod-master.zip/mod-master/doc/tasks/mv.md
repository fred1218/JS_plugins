## <a href="#mv" name="mv">mv</a>
> Move or rename files or directories

### Usage

```sh
$ mod mv <src> <dest>
```






