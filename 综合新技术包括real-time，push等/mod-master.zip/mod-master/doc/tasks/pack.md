## <a href="#pack" name="pack">pack</a>
> Create a tarball from a module

### Usage

```sh
$ mod pack <src> [options]
```

### Options

#### dest


<p> <b>&nbsp;&nbsp;&nbsp;&nbsp;Describe:</b> Target pack file path</p>
<hr>







