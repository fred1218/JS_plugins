## <a href="#rm" name="rm">rm</a>
> Remove files

### Usage

```sh
$ mod rm <dest>
```






