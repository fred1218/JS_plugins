# <%= name %>
## Tutorials
* [Getting Started](https://github.com/modjs/mod/tree/master/doc/tutorial/getting-started.md)
* [Configuring Tasks](https://github.com/modjs/mod/blob/master/doc/tutorial/configuring-tasks.md)
* [Creating Plugins](https://github.com/modjs/mod/tree/master/doc/tutorial/creating-plugins.md)

<% _.each(items, function(item) { print(item + "\n") }); %>
