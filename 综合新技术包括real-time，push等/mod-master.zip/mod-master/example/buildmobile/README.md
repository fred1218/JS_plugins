### Usage

super easy:

```sh
$ mod
```

