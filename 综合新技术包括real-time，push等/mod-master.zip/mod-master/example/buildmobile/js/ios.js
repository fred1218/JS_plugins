/* ios */
define(['./var/navigator'],function(navigator){
    var ios = /ios/i.test(navigator.userAgent);
})