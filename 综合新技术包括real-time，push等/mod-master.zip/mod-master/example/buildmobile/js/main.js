define([
    './var/zepto',
    './var/document',
    './var/navigator',
    './var/location',
    './ios'
], function ($, document, navigator, location, ios) {
    $('#hi').text("Hello ModJS");
})