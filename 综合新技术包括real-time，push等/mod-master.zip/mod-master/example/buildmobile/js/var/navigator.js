define(function(){
    return window.navigator;
})