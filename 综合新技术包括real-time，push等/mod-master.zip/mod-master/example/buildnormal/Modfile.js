// Mod.js
// More info at https://github.com/modjs/mod/

module.exports = {
    tasks: {
        build: {
            src: "./index.html"
        }
    }
};