### Usage

super easy:

```sh
$ mod build index.html
```

