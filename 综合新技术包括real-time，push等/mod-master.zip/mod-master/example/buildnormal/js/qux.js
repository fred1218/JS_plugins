(function stand(status){
    window['console'] && console.log(status);
})('quz');