(function stand(status){
    window['console'] && console.log(status);
})('alone');