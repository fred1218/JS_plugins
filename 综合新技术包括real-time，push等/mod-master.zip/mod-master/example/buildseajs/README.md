### Usage

super easy:

```sh
$ mod build index.html
```

### copyright

http://seajs.org/LICENSE.md