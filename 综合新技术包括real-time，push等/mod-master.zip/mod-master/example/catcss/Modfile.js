
module.exports = {
    tasks: {
        cat: {
            src: ["foo.css","bar.css"],
            dest: "dist/foobar.css"
        }
    }
};
