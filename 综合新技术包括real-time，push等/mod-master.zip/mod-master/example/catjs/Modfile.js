
module.exports = {
    tasks: {
        cat: {
            src: ["foo.js", "bar.js"],
            dest: "dist/foobar.js"
        }
    }
};
