/* async module */
define(['./var/navigator'],function(navigator){
    return "async Module loaded"
})