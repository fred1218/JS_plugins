/* sync Module */
define(['./var/navigator'],function(navigator){
    return "sync Module loaded"
})