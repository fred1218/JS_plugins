define(function (require) {
    return {a:1, b: require('./b')};
});