define(function (require) {
    return {b:2, c: require('./c')};
});