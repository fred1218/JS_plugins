define(function (require) {
    return {c:3};
});