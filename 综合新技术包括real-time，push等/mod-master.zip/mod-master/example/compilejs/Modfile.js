// Modfile
module.exports = {
    tasks: {
        compile: {
            src: "conditional.js"
        }
    }
};