### Usage

super easy:

```sh
$ mod
```

### copyright

https://github.com/requirejs/example-multipage-shim