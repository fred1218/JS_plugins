var foo='';
var bar= '';
