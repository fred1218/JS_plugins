
module.exports = {
    tasks: {
        datauri: {
            src: "test.css",
            dest: "dist/test.datauri.css",
            igts: true
        }
    }
};