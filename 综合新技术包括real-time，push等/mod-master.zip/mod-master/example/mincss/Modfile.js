
module.exports = {
    tasks: {
        min: {
            src: "test.css",
            dest: "dist/test.min.css"
        }
    }
};