
module.exports = {
    tasks: {
        min: {
            src: "*.html",
            dest: "./dist"
        }
    }
};