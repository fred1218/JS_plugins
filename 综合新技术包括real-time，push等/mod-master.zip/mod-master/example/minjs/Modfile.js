
module.exports = {
    tasks: {
        min: {
            src: "./js/*.js"
        }
    }
};