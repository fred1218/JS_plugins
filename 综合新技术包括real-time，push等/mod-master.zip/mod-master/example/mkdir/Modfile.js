
module.exports = {
    tasks: {
        mkdir: {
            dest: "dist"
        }
    }
};
