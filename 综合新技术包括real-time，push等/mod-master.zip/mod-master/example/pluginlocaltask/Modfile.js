
module.exports = {
    plugins: {
        mytask: "./mytask"
    },
    tasks : {
        mytask : {
            text: "hello modjs"
        }
    }
};