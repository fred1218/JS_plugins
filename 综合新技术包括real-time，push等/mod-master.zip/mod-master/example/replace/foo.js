var ts = TIMESTAMP;
var debug = DEBUG;
var ver = "v1";
