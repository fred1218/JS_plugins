
module.exports = {
    tasks: {
        strip: {
            src: "foo.js",
            dest: "dist/foo.js",
            eol: 'lf',
			tab: '  '
        }
    }
};