{{name}}
===

{{description}}


## Usage

```js
module.exports = {
    plugins: {
        "{{name}}": "{{name}}"
    },
    tasks: {
        "{{name}}": {
            src: "",
            dest: ""
        }
    }
};
```
