
module.exports = {
    plugins: {
        apitesting: "./apitesting"
    },
    tasks : {
        apitesting : {}
    }
};