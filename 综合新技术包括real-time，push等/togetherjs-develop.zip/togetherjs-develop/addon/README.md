The Firefox Addon simply adds togetherjs.js to a window - when you turn
it on the tab gets togetherjs for that one tab, and when you turn it off
it stops.
