# FAQ

## When I add a field dynamically it doesn't appear on the other person's page!

## Will I see what the other person is seeing?

## Why not synchronize everything?

## Should I host my own server?

## How stable is TogetherJS?

## Does it work on an intranet?
