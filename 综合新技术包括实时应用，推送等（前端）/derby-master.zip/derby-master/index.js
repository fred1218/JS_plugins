var Derby = require('./lib/Derby');
module.exports = new Derby();
