## Moduleloader Hook

This hook loads modules from your configured directories in sails.config.paths.  It is always loaded first or second.

##### Contributing to this hook
Not a good place to jump in right now.  Please tweet @mikermcneil before working on this part!
