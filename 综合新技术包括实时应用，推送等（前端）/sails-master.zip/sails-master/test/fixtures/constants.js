/**
 * Constants about the Sails framework.
 * For use in tests.
 *
 * @type {Object}
 */
module.exports = {
	EXPECTED_DEFAULT_HOOKS: require('../../lib/app/configuration/default-hooks')
};
