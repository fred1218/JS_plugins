module.exports = {
	schema: false,
	attributes: {
    foo: 'string'
  }
};
