<?php

ini_set('display_errors',0);

header('Content-Type: text/html');

echo microtime(true);
