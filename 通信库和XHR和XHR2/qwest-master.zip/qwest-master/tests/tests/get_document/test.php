<?php header('Content-Type: text/html'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title>test</title>
		<meta charset="utf-8">
	</head>
	<body>
		<p>ok</p>
	</body>
</html>