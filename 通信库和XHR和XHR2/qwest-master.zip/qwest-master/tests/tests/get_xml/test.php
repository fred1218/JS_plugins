<?php header('Content-Type: text/xml'); ?>
<?xml version="1.0" encoding="UTF-8"?>
<data>
	<status>ok</status>
</data>