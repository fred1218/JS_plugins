var falcor = require("./browser.js");
var Router = require("falcor-router");

falcor.Router = Router;

module.exports = falcor;
