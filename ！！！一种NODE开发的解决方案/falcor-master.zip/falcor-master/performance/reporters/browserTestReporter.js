module.exports = {
    resultsReporter: function(results) {
        console.log(results);
    },

    benchmarkReporter: function(benchmark) {
        console.log(benchmark);
    }
};