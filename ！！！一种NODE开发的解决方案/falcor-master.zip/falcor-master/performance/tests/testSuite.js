module.exports = function(name) {
    return {
        name: name,
        tests: {}
    };
};
