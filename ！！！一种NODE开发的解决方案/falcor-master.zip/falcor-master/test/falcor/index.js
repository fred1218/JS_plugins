describe('Operations', function() {
    require('./get');
    require('./set');
    require('./call');
    require('./invalidate');
    require('./schedulers');
    require('./deref');
    require('./error');
});
