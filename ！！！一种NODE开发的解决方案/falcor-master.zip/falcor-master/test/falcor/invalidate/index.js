describe('Invalidate', function() {
    require('./invalidate.cache-only.spec');
    require('./invalidate.change-handler.spec');
});
