describe('Set', function() {
    require('./set.cache-only.spec');
    require('./set.dataSource-only.spec');
    require('./set.dataSource-and-bind.spec');
    require('./set.dataSource-and-cache.spec');
    require('./set.cacheAsDataSource-and-cache.spec');
    require('./set.pathSyntax.spec');
    require('./set.change-handler.spec');
    require('./set.setCache.spec');
});
