describe('HardLink', function() {
    require('./hardlink.add.spec');
    require('./hardlink.remove.spec');
});
