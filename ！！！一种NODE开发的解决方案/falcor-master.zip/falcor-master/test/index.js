describe("Falcor", function() {
    require("./Model.spec.js");
    require("./integration");
});

