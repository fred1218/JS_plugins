describe('Integration', function() {
    require('./call.spec');
    require('./express.spec');
    require('./get.spec');
});
