describe('Internal', function() {
    require('./request/GetRequest.spec');
    require('./request/RequestQueue.spec');
});
