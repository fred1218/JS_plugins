describe('GetRequest', function() {
    require('./GetRequest.batch.spec');
    require('./GetRequest.add.spec');
});
