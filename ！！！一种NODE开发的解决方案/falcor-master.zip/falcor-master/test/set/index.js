module.exports = function() {
    describe("Set Core", function() {
        require("./pathValues");
        require("./pathMaps");
        require("./jsonGraphs");
        require("./edge-cases.spec");
    });
};