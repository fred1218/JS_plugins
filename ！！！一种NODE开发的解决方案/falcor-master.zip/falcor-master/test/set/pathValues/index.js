describe("setPathValues", function() {
    require("./primitive.spec");
    require("./atom.spec");
    require("./expired.spec");
    require("./branch.spec");
});